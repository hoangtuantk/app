import DOMElements from './dom.js';
import { initializeDictionaries, clearAllDictionaries, loadDictionariesFromFile, loadDictionariesFromServer } from './dictionary.js';
import { customAlert, customConfirm } from './dialog.js'; 
import { initializeNameList, buildMasterKeySet } from './nameList.js';
import { initializeModal } from './modal.js';
import { performTranslation } from './translation.js';

// Hàm này chỉ thêm một dòng log mới vào danh sách
function appendLog(message, type) {
    const li = document.createElement('li');
    let icon = '';

    if (type === 'loading') {
        icon = '<div class="w-4 h-4 border-2 border-dashed rounded-full animate-spin border-accent-color spinner-icon"></div>';
    } else if (type === 'success') {
        icon = '<span>✅</span>';
    } else if (type === 'error') {
        icon = '<span>❌</span>';
    } else {
        icon = '<span>ℹ️</span>';
    }

    li.innerHTML = `${icon}<span>${message}</span>`;
    li.classList.add(`log-${type}`);
    DOMElements.logList.appendChild(li);

    // Tự động cuộn xuống cuối danh sách
    DOMElements.logList.scrollTop = DOMElements.logList.scrollHeight;
    return li; // Trả về phần tử li để có thể cập nhật sau này
}

// Hàm mới để cập nhật một dòng log đã có
function updateLog(li, message, type) {
    let icon = '';
    if (type === 'success') {
        icon = '<span>✅</span>';
    } else if (type === 'error') {
        icon = '<span>❌</span>';
    } else {
        icon = '<span>ℹ️</span>';
    }

    li.innerHTML = `${icon}<span>${message}</span>`;
    li.classList.remove('log-loading');
    li.classList.add(`log-${type}`);
}


document.addEventListener('DOMContentLoaded', async () => {
    const state = {
        dictionaries: null,
        masterKeySet: new Set(),
    };

    let isImporting = false

    // Vô hiệu hóa loader ban đầu
    DOMElements.loader.style.display = 'none';

    // Cập nhật state sau khi có từ điển mới
    const updateState = (newDicts) => {
        state.dictionaries = newDicts;
        initializeNameList(state);
        initializeModal(state);
        // Bật các nút chức năng sau khi có từ điển
        DOMElements.translateBtn.disabled = false;
        DOMElements.modeToggle.disabled = false;
    };

    // Load từ điển đã có sẵn trong IndexedDB (nếu có)
    const db = await initializeDictionaries();
    if (db) {
        updateState(db);
    }

    // Kết nối các nút mới
    DOMElements.importLocalBtn.addEventListener('click', () => {
        if (isImporting) return;
        DOMElements.logModal.classList.remove('hidden');
        DOMElements.logList.innerHTML = '';
        DOMElements.fileImporter.click();
    });
    
    DOMElements.fileImporter.addEventListener('change', async (e) => {
        if (isImporting) return;
        isImporting = true;
        DOMElements.importLocalBtn.disabled = true;
        DOMElements.importServerBtn.disabled = true;
        
        const files = e.target.files;
        if (files.length > 0) {
            const logHandler = { append: appendLog, update: updateLog };
            const newDicts = await loadDictionariesFromFile(files, logHandler);
            updateState(newDicts);
        }
        e.target.value = null;

        isImporting = false;
        DOMElements.importLocalBtn.disabled = false;
        DOMElements.importServerBtn.disabled = false;
    });

    DOMElements.importServerBtn.addEventListener('click', async () => {
        if (isImporting) return;
        isImporting = true;
        DOMElements.importLocalBtn.disabled = true;
        DOMElements.importServerBtn.disabled = true;

        DOMElements.logModal.classList.remove('hidden');
        DOMElements.logList.innerHTML = '';
        const logHandler = { append: appendLog, update: updateLog };
        const newDicts = await loadDictionariesFromServer(logHandler);
        updateState(newDicts);

        isImporting = false;
        DOMElements.importLocalBtn.disabled = false;
        DOMElements.importServerBtn.disabled = false;      
    });

    DOMElements.clearDbBtn.addEventListener('click', async () => {
        if (await customConfirm('Bạn có chắc muốn xóa toàn bộ từ điển đã lưu? Hành động này không thể hoàn tác.')) { // THAY ĐỔI DÒNG NÀY
            await clearAllDictionaries();
            await customAlert('Đã xóa dữ liệu từ điển. Vui lòng nhập lại từ điển.');
            // Reset trạng thái
            state.dictionaries = null;
            state.masterKeySet = new Set();
            DOMElements.outputPanel.textContent = 'Kết quả sẽ hiện ở đây...';
            // Vô hiệu hóa các nút chức năng
            DOMElements.translateBtn.disabled = true;
            DOMElements.modeToggle.disabled = true;
        }
    });

    DOMElements.closeLogModalBtn.addEventListener('click', () => {
        DOMElements.logModal.classList.add('hidden');
        DOMElements.logList.innerHTML = '';
    });

    DOMElements.logModal.addEventListener('click', (e) => {
        if (e.target === DOMElements.logModal) {
            DOMElements.logModal.classList.add('hidden');
            DOMElements.logList.innerHTML = '';
        }
    });

    // Kích hoạt nút dịch để bắt đầu quá trình dịch
    DOMElements.translateBtn.addEventListener('click', () => performTranslation(state));
    
    DOMElements.clearBtn.addEventListener('click', () => {
        DOMElements.inputText.value = '';
        DOMElements.outputPanel.textContent = 'Kết quả sẽ hiện ở đây...';
    });




    // Trong phần xử lý sự kiện click của nút copyBtn
    DOMElements.copyBtn.addEventListener('click', () => {
        const outputPanel = DOMElements.outputPanel;
        if (outputPanel.textContent.trim().length === 0 || outputPanel.textContent.trim() === 'Kết quả sẽ hiện ở đây...') {
            return;
        }

        // Tạo một phạm vi chọn mới
        const range = document.createRange();
        range.selectNodeContents(outputPanel);
        
        // Xóa các lựa chọn hiện có
        const selection = window.getSelection();
        selection.removeAllRanges();
        
        // Thêm phạm vi mới
        selection.addRange(range);

        try {
            // Thực hiện sao chép
            document.execCommand('copy');
            
            // Thông báo sao chép thành công
            const originalText = DOMElements.copyBtn.textContent;
            DOMElements.copyBtn.textContent = 'Đã sao chép!';
            DOMElements.copyBtn.disabled = true;
            
            setTimeout(() => {
                DOMElements.copyBtn.textContent = originalText;
                DOMElements.copyBtn.disabled = false;
            }, 300);
        } catch (err) {
            console.error('Không thể sao chép tự động:', err);
            outputPanel.focus();
            document.execCommand('selectAll');
        }

    });
    
    DOMElements.modeToggle.addEventListener('change', () => performTranslation(state));

    let currentFontSize = parseInt(localStorage.getItem('translatorFontSize') || '18');
    const baseFontSize = 18;

    const updateFontSize = () => {
        DOMElements.outputPanel.style.fontSize = `${currentFontSize}px`;
        const percent = Math.round((currentFontSize / baseFontSize) * 100);
        DOMElements.fontSizeLabel.textContent = `${percent}%`;
        localStorage.setItem('translatorFontSize', currentFontSize);
    };

    DOMElements.increaseFontBtn.addEventListener('click', () => {
        currentFontSize += 1;
        updateFontSize();
    });

    DOMElements.decreaseFontBtn.addEventListener('click', () => {
        if (currentFontSize > 8) {
            currentFontSize -= 1;
            updateFontSize();
        }
    });

    updateFontSize();
});